package com.cognizant.transactionservice.initializer;

import org.junit.jupiter.api.Test;

//import com.cognizant.accountservice.AccountserviceApplication;
import com.cognizant.transactionservice.TransactionserviceApplication;

public class ServletInitializerTest {

	@Test
	public void main() {
		TransactionserviceApplication.main(new String[] {});
	}

}
